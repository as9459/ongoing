package modele.dao;

public class DaoType_charges {

}
